<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Platform-and-Objects" tilewidth="16" tileheight="16" tilecount="64" columns="8">
 <image source="Platform-and-Objects.png" width="128" height="128"/>
 <tile id="32">
  <animation>
   <frame tileid="32" duration="100"/>
   <frame tileid="33" duration="100"/>
   <frame tileid="34" duration="100"/>
   <frame tileid="35" duration="100"/>
   <frame tileid="36" duration="100"/>
   <frame tileid="37" duration="100"/>
   <frame tileid="38" duration="100"/>
  </animation>
 </tile>
</tileset>
