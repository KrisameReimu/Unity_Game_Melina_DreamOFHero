# Japan Neighborhood Pixel Art Tileset / Koneko Dark - Basic

- https://theflavare.itch.io/forest-nature-fantasy-tileset

Thank you for downloading the assets!

If you have any question please email to hello@theflavare.com or discuss on itch io forum. Any question and suggest are welcome.

## Specification :

- hi-bit pixel art
- Atmospheric color
- Tileset at 16x16
- Available with Tiled sample
- Multiple Parallax Background
- Seamless Background

\*Tileset comes with 2 version, The Basic and Premium. You already can use basic version on your game. You can see in the mockup screenshot for the different.

Enjoy :D
